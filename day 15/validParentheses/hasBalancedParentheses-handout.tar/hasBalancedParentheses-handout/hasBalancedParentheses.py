
def hasBalancedParentheses(s):
	return False

print(hasBalancedParentheses(input()))