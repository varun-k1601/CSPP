a=1
print("Initial integer value:",a)
a=2
print("Changed integer value:",a)
b=20.1
print("Initial float value:",b)
b=25.5
print("Changed float value:",b)
c="IIIT Hyderabad"
print("Initial string value:",c)
c=c+" MSIT"
print("Changed string value:",c)

i=100
j=200
print("Before swap:",i,j)
i=i+j
j=i-j
i=i-j
print("After swap:",i,j)