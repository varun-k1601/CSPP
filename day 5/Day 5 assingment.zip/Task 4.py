a=10
prin t(a) #It is intentionally not following the syntax
print(b) #It is trying to use undefined variable known as name error
c="MSIT"
print(float(c)) #we are trying to send unexpected value here known as value error
f=10+"MSIT"
print(f)#It is known as type error because we are trying to perform invalid operation between two incompatible data types
d=10/0
print(d) #It is known as Zero division error because we are trying to divide it with zero
import p
print(p) #It is known as module not found error because we are trying to import non-existent module
