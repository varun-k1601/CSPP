a=10 #it is used to represent only integer values
b=20.5 #it is used to represent only float values
c="MSIT" #it is used to represent only string values
d=True #Boolean values are used to represent given condition is true or false
e="b"
print(f) #Name error is nothing but the value is assigned to one variable but we are trying to print another variable which is not defined