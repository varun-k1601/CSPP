a=10
b=20.5
c="MSIT"
d=True
print("Integer:",type(a),",""Value =",a)
print("Float:",type(b),",""Value =",b)
print("String:",type(c),",""Value =",c)
print("Boolean:",type(d),",""Value =",d)
print("Integer to float:",float(a))
print("Float to integer:",int(b))
print("Float to string:",str(b))